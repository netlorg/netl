/* do not modify */
#define NETL_VER_MAJOR 1
#define NETL_VER_MINOR 8
#define COPYVER "1.09 copyright 1997-1999 Graham THE Ollis <ollisg@netl.org>"
#define NETL_LIB_PATH "/usr/local/lib/netl-1.09"
#define NETL_DUMP_PATH "/usr/local/lib/netl-1.09/dump"
#define NETL_CONFIG "/etc/netl.conf"
#define NETL_CC "gcc"
#define NETL_INCLUDEPATH "/usr/local/lib/netl-1.09/include"
#define NETL_PERLPATH "/usr/local/bin/perl"
