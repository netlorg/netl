

package Netl::Dirs;

$startperl = "#!/usr/local/lang/perl/bin/perl"
$libdir = "/usr/local/lib//usr/local/lib/netl-1.04";
$incdir = "/usr/local/lib/netl/include";

1;
