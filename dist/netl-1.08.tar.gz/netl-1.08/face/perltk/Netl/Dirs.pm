

package Netl::Dirs;

$startperl = "#!/usr/local/lang/perl/bin/perl"
$libdir = "/usr/local/lib/netl-1.08";
$incdir = "/usr/local/lib/netl-1.08/include";

1;
