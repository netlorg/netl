#ifndef SIGHANDLE_H
#define SIGHANDLE_H

/*==============================================================================
| sighandle.c - the signal handling module
==============================================================================*/

void	handle();
void	sig_handler(int sig);

#endif
