/*==============================================================================
| slog - log EVERYTHING possible
| 
| extended and tested under linux 2.0.23, 2.0.26
|  by graham the ollis <ollisg@ns.arizona.edu>
|
| your free to modify and distribute this program as long as this header is
| retained, source code is made *freely* available and you document your 
| changes in some readable manner.
==============================================================================*/

/* "@(#) slog config.h" */

/*==============================================================================
| name of the facility to be passed to openlog(), which controls where the 
| log information goes when you play around with /etc/syslog.conf.
| i personally have pingl go in to local4 which splits and is logged in both
| ~adm/pinglog and ~adm/messages.
==============================================================================*/
#define PINGL_LOG_FACILITY	LOG_LOCAL4
#define SYNLOG_LOG_FACILITY	LOG_LOCAL5

/*==============================================================================
| You should probably only define one of these.  LOG_HOST logs host names
| LOG_IP will log IP numbers only.  If both are defined then you'll get
| twice as many lines in your log files for every ping and every syn.
| yuck!
==============================================================================*/
#define LOG_HOST
/*#define LOG_IP*/

/*==============================================================================
| LOG_ICMP_* for each defined, log the given type of ICMP packet
| comment out if you don't think it necessary to log a particular type of
| ICMP packet.
|
| this effects pingl ONLY
==============================================================================*/
#define LOG_ICMP_ECHO		/* ping */
#define LOG_ICMP_ECHOREPLY	/* pong */

/*==============================================================================
| the localhost's ip address (the real one, not the 127.0.0.1)
| and how you want that host to show up in the log.
==============================================================================*/
#define LOCAL_HOST		{150, 135, 73, 56}
#define LOCAL_HOST_NAME		"figment"

/*==============================================================================
| NO_SELF_LOG define if you don't want 127.0.0.1 showing up in your synlog
|
| NO_SYN_LOG the src hosts you don't want to log (IP number)
|            this should be your REAL host IP number unless you
|            like a line in your log file for every http connection
|            you make
| NO_SYN_LOG_MAX the number of hosts in NO_SYN_LOG
==============================================================================*/
#define NO_SELF_LOG
#define NO_SYN_LOG_MAX		1
#define NO_SYN_LOG		{ LOCAL_HOST }

