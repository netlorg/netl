/*==============================================================================
| resolve.c
|   do host name look ups in something of an efficent manner
|
| (c) 1997 Graham THE Ollis
|
|  Date       Name	Revision
|  ---------  --------  --------
|  08 Feb 97  G. Ollis	created
|  23 Feb 97  G. Ollis	account for the possible failure of a hostname lookup
|=============================================================================*/

#include <netdb.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "slog.h"

struct listtype {
  unsigned char ip[4];			/* ip number: x.x.x.x		*/
  struct listtype *next;		/* next node			*/
  char *name;				/* hostname			*/
};

static struct listtype *cache = NULL;

char *search(unsigned char *ip);

/*==============================================================================
| addip();
| add an ip/hostname to the search stack.  this is handy for local aliases.
|=============================================================================*/

char *
addip(const char *s, unsigned char *ip)
{
  struct listtype	*tmp;
  int			len;

  tmp = (struct listtype *) malloc(sizeof(struct listtype));
  tmp->name = (char *) malloc((len = strlen(s) + 1));
  memcpy(tmp->name, s, len);
  memcpy(tmp->ip, ip, 4);
  tmp->next = cache;
  cache = tmp;

  return tmp->name;
}

/*==============================================================================
| ip2string();
| convert an ip number and return a pointer to an internal string.  the
| name has been cached so next look up should be marginally faster.
|=============================================================================*/

char *
ip2string(unsigned char *ip)
{
  char			buff[20];
  struct hostent *	herhost;
  char *		tmp;

  if((tmp=search(ip)) != NULL)
    return tmp;

  sprintf(buff, "%d.%d.%d.%d", ip[0], ip[1], ip[2], ip[3]);
  if(
     ((herhost = gethostbyname(buff)) != NULL) &&
     ((herhost = gethostbyaddr(herhost->h_addr_list[0], 
                          herhost->h_length,
			  herhost->h_addrtype)) != NULL)
    ) {
    tmp = addip(herhost->h_name, ip);
  } else {
    tmp = addip(buff, ip);
  }

  return tmp;
}

/*==============================================================================
| search();
| convert an ip number and return a pointer to an internal string.  the
| name has been cached so next look up should be marginally faster.
|=============================================================================*/

char *
search(unsigned char *ip) 
{
  struct listtype *tmp;

  for(tmp = cache; tmp != NULL; tmp = tmp->next) {
    if(!memcmp(ip, tmp->ip, 4)) {
      return tmp->name;
    }
  }
  return NULL;
}

/*==============================================================================
| clearcache();
| clear the internal cache for this module.
|=============================================================================*/

void
clearipcache()
{
  struct listtype *tmp;

  for(tmp=cache; tmp != NULL; tmp = tmp->next) {
    free(tmp);
  }
  cache = NULL;
}
