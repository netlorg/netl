/*==============================================================================
| netl
|   optimized (and debugged) by Graham THE Ollis <ollisg@ns.arizona.edu>
|
| modifications are (c) 1997 Graham THE Ollis
|
| historic comment:
|   This program will log all SYNs
|   This program is a complete hack.  It is not meant as an example of 
|   how to program, let alone cook potatoes.  Use at your own risk, and by
|   god, look both directions before crossing the street.
|===============================================================================
| modern comments:
|   this program is now written like it should be.
|   your free to modify and distribute this program as long as this header is
|   retained, source code is made *freely* available and you document your 
|   changes in some readable manner.
|
|  Date       Name	Revision
|  ---------  --------  --------
|  01 Feb 97  G. Ollis	modified, commented (and debugged)
|  08 Feb 97  G. Ollis	added IP address resolving.
|  23 Feb 97  G. Ollis	combined all network monitoring in to single program
|=============================================================================*/

char	*id = "@(#)netl by graham the ollis <ollisg@ns.arizona.edu>";

#include <unistd.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <stdio.h>
#include <linux/if_ether.h>
#include <linux/if.h>
#include <time.h>
#include <syslog.h>
#include "config.h"
#include "slog.h"

/*==============================================================================
| Globals
|=============================================================================*/

unsigned char localhost[4] = {127, 0, 0, 1};
unsigned char localaliases[NO_SYN_LOG_MAX][4] = NO_SYN_LOG;
struct ifreq oldifr, ifr;

/*==============================================================================
| Prototypes
|=============================================================================*/

void logline(unsigned char *buff);
int synl(char *dev);

/*==============================================================================
| int main(int, char **)
|=============================================================================*/

int
main(int argc, char *argv[])
{
  char		dev[255] = "eth0";
  pid_t		temp;

  if(argc >= 2)
    strcpy(dev, argv[1]);

  puts("netl 1.0 by graham the ollis <ollisg@ns.arizona.edu>");

  if((temp = fork()) == 0) 
    return synl(dev);

  if(temp == -1) {
    fprintf(stderr, "%s: unable to fork\n", argv[0]);
    return 1;
  }

  return 0;
}

/*==============================================================================
| void synl(char *)
|=============================================================================*/

int
synl(char *dev) {
  int		l;
  int		sock, length;
  struct	sockaddr_in name;
  unsigned char buf[4096];
  unsigned int	fromlen;

  addip(LOCAL_HOST_NAME, localaliases[0]);

  openlog("netl", 0, SYNLOG_LOG_FACILITY);
  syslog(LOG_INFO, "starting synl, logging %s", dev);
  handle();

  /*============================================================================
  | Get a socket which will collect all packets
  |===========================================================================*/
  sock = socket(AF_INET, SOCK_PACKET, htons(ETH_P_ALL));

  if (sock < 0) {
    syslog(LOG_ERR, "cannot open raw socket, die\n", stderr);
    return 1;
  }

  /*============================================================================
  | Configure ethernet device
  |===========================================================================*/

  strcpy(ifr.ifr_name, dev);
  strcpy(oldifr.ifr_name, dev);

  /*============================================================================
  | Get flags and place them in ifr structure
  |===========================================================================*/

  if(ioctl(sock, SIOCGIFFLAGS, &ifr) < 0) {
    syslog(LOG_ERR, "unable to get %s flags, die", dev);
    return 1;
  }

  /*============================================================================
  | Get flags and place them in oldifr structure
  | This will be used later to change ether device characteristics back
  | to their original value
  |===========================================================================*/

  if(ioctl(sock, SIOCGIFFLAGS, &oldifr) < 0) {
    syslog(LOG_ERR, "unable to get %s flags, die\n", dev);
    return 1;
  }

  /*============================================================================
  | Set the promiscous flag
  |===========================================================================*/

  ifr.ifr_flags |= IFF_PROMISC;

  /*============================================================================
  | Set the device flags
  |===========================================================================*/

  if(ioctl(sock, SIOCSIFFLAGS, &ifr) < 0) {
    syslog(LOG_ERR, "Unable to set %s flags, die", dev);
    return 1;
  } 

  /*============================================================================
  | Set up sockaddr
  |===========================================================================*/

  name.sin_family = AF_INET;
  name.sin_addr.s_addr = INADDR_ANY;
  name.sin_port = 0;

  length = sizeof(name);

  if (getsockname(sock, (struct sockaddr *) &name, &length) < 0) {
    syslog(LOG_ERR, "Error: Can't get socket name, die");
    return 1;
  }

  /*============================================================================
  | Entering the data collection loop
  |===========================================================================*/

  for(;;) {
    if((l = recvfrom(sock, buf, 1024, 0, (struct sockaddr *)&name, &fromlen)) < 0)
      syslog(LOG_ERR, "Error receiving RAW packet\n");
    else {


      /*========================================================================
      | Check to make sure this is an IP packet
      | The number starts high as the ethernet frame is in the buffer as well.
      |=======================================================================*/

      if(buf[14] == 0x45 || buf[14] == 0x54) {

        /*======================================================================
        | Verify that it is protocol 6 & type is SYN.
        |=====================================================================*/

        if(buf[23] == 6 && buf[47] == 0x02) {
          logline(buf);
        }
      }
    }

  }

  close(sock);
  exit(0);

  return 0;
}

/*==============================================================================
| void logline(char *buf)
|=============================================================================*/

void logline(unsigned char *buf)
{

#ifdef NO_SYN_LOG
  int i;
  for(i=0; i < NO_SYN_LOG_MAX; i++)
    if(!memcmp(&buf[26], localaliases[i], 4))
      return;  
#endif

#ifdef NO_SELF_LOG
  if(!memcmp(&buf[26], localhost, 4) || !memcmp(&buf[30], localhost, 4))
    return;
#endif

#ifdef LOG_HOST
  syslog(LOG_NOTICE, "%s:%d => %s:%d",
			ip2string(&buf[26]), (buf[34] << 8) + buf[35],
			ip2string(&buf[30]), (buf[36] << 8) + buf[37]);
#endif

#ifdef LOG_IP
  syslog(LOG_NOTICE, 
          "%d.%d.%d.%d:%d => %d.%d.%d.%d:%d\n",

          /*====================================================================
          | source address as IP:port
          |===================================================================*/

          buf[26], buf[27], buf[28], buf[29],
          (buf[34] << 8) + buf[35],

          /*====================================================================
          | destination address as IP:port
          |===================================================================*/

          buf[30], buf[31], buf[32], buf[33],
          (buf[36] << 8) + buf[37]);
#endif

}

