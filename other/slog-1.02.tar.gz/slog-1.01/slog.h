/*==============================================================================
| slog - log EVERYTHING possible
| 
| extended and tested under linux 2.0.23, 2.0.26
|  by graham the ollis <ollisg@ns.arizona.edu>
|
| your free to modify and distribute this program as long as this header is
| retained, source code is made *freely* available and you document your 
| changes in some readable manner.
==============================================================================*/

/*==============================================================================
| resolve.c - the ip resolution module
==============================================================================*/

char *ip2string(unsigned char *ip);
char *addip(const char *s, unsigned char *);
void clearipcache();

/*==============================================================================
| sighandle.c - the signal handling module
==============================================================================*/

void	handle();
void	sig_handler(int sig);
