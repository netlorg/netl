/*==============================================================================
| SynWatch
|   written by Jeff Thompson (jwthomp@uiuc.edu)
|  This program will log all SYNs
|=============================================================================*/

#include <stdio.h>
#include <stdlib.h>
#include "connect.h"

/*==============================================================================
| connection * addconnection(char *, connection *)
|=============================================================================*/

struct connection *
addconnection(char *buf, struct connection *head)
{
  struct connection *tmp;
  tmp = (struct connection *) malloc(sizeof(struct connection));

  memcpy(tmp, &buf[26], 8);

  tmp->srcport = (buf[34] & 0xff) * 256 + (buf[35] & 0xff);
  tmp->dstport = (buf[36] & 0xff) * 256 + (buf[37] & 0xff);

  tmp->next = head;
  tmp->prev = NULL;

  if(head != NULL)
    head->prev = tmp;
  head = tmp;

  return(tmp);
}

/*==============================================================================
| int newconnection(char *, connection *)
|=============================================================================*/

int
newconnection(char *buf, struct connection *head)
{
  struct connection *tmp;
  tmp = head;
  while(tmp != NULL) {
    if( !memcmp(tmp, &buf[26], 8) &&

    (tmp->srcport == (buf[34] & 0xff) * 256 + (buf[35] & 0xff)) &&
    (tmp->dstport == (buf[36] & 0xff) * 256 + (buf[37] & 0xff))) 
      return 0;

    tmp = tmp->next;
  }
  return 1;
}

/*==============================================================================
| int printconnections(char *, connection *)
|=============================================================================*/

int
printconnections(struct connection *head)
{
  int num = 0;
  struct connection *tmp;
  tmp = head;

  while(tmp != NULL) {
    printf("%d: src:%d.%d.%d.%d %d dst:%d.%d.%d.%d %d\n",
    num, 
    tmp->srcip[0] & 0xff,
    tmp->srcip[1] & 0xff,
    tmp->srcip[2] & 0xff,
    tmp->srcip[3] & 0xff,
    tmp->srcport & 0xffff,
    tmp->dstip[0] & 0xff,
    tmp->dstip[1] & 0xff,
    tmp->dstip[2] & 0xff,
    tmp->dstip[3] & 0xff,
    tmp->dstport & 0xffff);
    tmp = tmp->next;
    num++;
  }

  return (num);
}


