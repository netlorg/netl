/*==============================================================================
| pingl 1.1 (was pinglogger)
| 
| Compiled and tested under Linux 1.2.13
|  By, Jeff Thompson(jwthomp@uiuc.edu)
|
| extended and tested under linux 2.0.23, 2.0.26
|  by graham the ollis <ollisg@ns.arizona.edu>
|
| modifications are (c) 1997 Graham THE Ollis
|
| your free to modify and distribute this program as long as this header is
| retained, source code is made *freely* available and you document your 
| changes in some readable manner.
|===============================================================================
|  Date       Name	Revision
|  ---------  --------  --------
|  -- --- 96  G. Ollis	modified, commented
|=============================================================================*/

char	*id = "@(#)pingl by graham the ollis <ollisg@ns.arizona.edu>";

#include <netinet/in.h>
#include <stdio.h>
#include <unistd.h>
#include <syslog.h>
#include "config.h"
#include "slog.h"

/*============================================================================*/

/* macros */
#define error(s) {fputs(prog_name,stderr); fputs(": " s "\n",stderr);}

/* types */
typedef unsigned int word;
typedef unsigned char byte;
typedef time_t timet;
typedef struct sockaddr_in saddr;

/* prototypes */
int	pinglog();

/* globals */
char	*prog_name = NULL;	/* "pingl" */

/*============================================================================*/

int
main(int argc, char *argv[])
{
  pid_t temp;

  puts("pingl 1.1 by graham the ollis <ollisg@ns.arizona.edu>.");

  prog_name = argv[0];

  if((temp = fork()) == 0)
    return pinglog();

  if(temp == -1) {
    error("unable to fork");
    return 1;
  }

  return 0;
}

/*============================================================================*/

int
pinglog()
{
  int	l;
  int	sock, length;
  saddr	name;
  byte	buf[1024];
  int	code, type;

  openlog("pingl", 0, PINGL_LOG_FACILITY);
  syslog(LOG_INFO, "starting ping daemon");
  handle();

  /* Open a raw icmp socket in order to receive all ICMP packets */
  sock = socket(AF_INET, SOCK_RAW, IPPROTO_ICMP);

  if (sock < 0) {
    syslog(LOG_ERR, "cannot open raw ICMP socket, die");
    return 1;
  }

  /* Set up the sockaddr structure */
  name.sin_family = AF_INET;
  name.sin_addr.s_addr = INADDR_ANY;
  name.sin_port = 0;

  /* Bind the socket */
  if (bind(sock, (struct sockaddr *) &name, sizeof name ) < 0) {
    syslog(LOG_ERR, "error binding ICMP socket, die");
    return 1;
  }

  length = sizeof(name);

  if (getsockname(sock, (struct sockaddr *) &name, &length) < 0) {
    syslog(LOG_ERR, "can't get socket name, die");
    return 1;
  }

  /* Main loop */
  for(;;) {

    if((l = read(sock, buf, 1024)) < 0)
      syslog(LOG_WARNING, "error receiving ICMP packet, warn");


    /* grab ICMP type and code from buffer */
    type = buf[20];
    code = buf[21];

#ifdef LOG_ICMP_ECHO
    /* Checks if this ICMP packet is an ICMP ECHO REQUEST */
    if(type == 8 && code == 0) {
 #ifdef LOG_IP
        syslog(LOG_NOTICE, "ICMP echo request: %d.%d.%d.%d",
              buf[12], buf[13], buf[14], buf[15]);
 #endif
 #ifdef LOG_HOST
	syslog(LOG_NOTICE, "ICMP echo request: %s", ip2string(&buf[12]));
 #endif
    }
#endif

#ifdef LOG_ICMP_ECHOREPLY
    if(type == 0 && code == 0) {
 #ifdef LOG_IP
        syslog(LOG_NOTICE, "ICMP echo reply: %d.%d.%d.%d",
              buf[12], buf[13], buf[14], buf[15]);        
 #endif
 #ifdef LOG_HOST
	syslog(LOG_NOTICE, "ICMP echo reply: %s", ip2string(&buf[12]));
 #endif
    }
#endif

  }

  close(sock);
  return 0;
}

