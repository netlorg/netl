#include <stdio.h>
#include <linux/types.h>
#include <linux/ip.h>

int
main(int argc,char *argv[])
{
  printf("%d 0x%x\n", sizeof(struct iphdr),
                      sizeof(struct iphdr));
}
