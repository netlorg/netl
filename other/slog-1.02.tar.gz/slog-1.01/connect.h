/*==============================================================================
| connect.h
|   written by, Jeff Thompson (jwthomp@uiuc.edu)
|   optimized (and debugged) by Graham THE Ollis <ollisg@ns.arizona.edu>
|  This program will log all SYNs
|
| modifications are (c) 1997 Graham THE Ollis and CORE
|
| historic comment:
|   This program is a complete hack.  It is not meant as an example of 
|   how to program, let alone cook potatoes.  Use at your own risk, and by
|   god, look both directions before crossing the street.
|===============================================================================
|  Date       Name	Revision
|  ---------  --------  --------
|  01 Feb 97  G. Ollis	modified, commented (and debugged)
|=============================================================================*/

#ifndef CONNECT_H
#define CONNECT_H

/*==============================================================================
| connect.h contains the structures for connect.c
| note: srcip and dstip must be (in that order) the first two members of
| this struct because i use memcpy() and memcmp() to access them in several
| places.
|=============================================================================*/

struct connection {
  char srcip[4];
  char dstip[4];
  int srcport;
  int dstport;
  unsigned long seq;
  struct connection *prev;
  struct connection *next;
  int ttl;
};

/*==============================================================================
| Prototypes
| These functions are found in connect.c (connect.o)
|=============================================================================*/

int newconnection(char *, struct connection *);
struct connection *addconnection(char *, struct connection *);
int printconnections(struct connection *);

#endif /* CONNECT_H */

