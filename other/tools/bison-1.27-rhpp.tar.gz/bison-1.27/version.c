#include <config.h>

char *version_string = "GNU Bison version " VERSION "\n";
