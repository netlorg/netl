/* Sniffit Packets include file                                                      */

unsigned short in_cksum(unsigned short *,int);
int unwrap_packet (const unsigned char *, struct unwrap *);

